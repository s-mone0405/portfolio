/* 
*プログラム名: LRU方式シミュレーションプログラム（LRU.c）
*作成者: 齋藤 桃音
*作成日: 2020/10/16
*概 要 : LRU方式をシミュレーションする
*/

#include <stdio.h>
#define  MAX 5			// 最大ページ数
#define  NOTFOUND -1		// 該当なし

/* 関数プロトタイプ宣言 */
void init_page(void);		// ページの初期化
int ispage(int num);		// ページの検索
void page_in(int num);		// ページイン
void page_out(int num);		// ページアウト
void status_update(int num);	// 閲覧履歴（優先順位）の更新
void disp_page(void);		// 格納データの表示

/* グローバル変数の宣言 */
int pages[MAX];			// 格納要素
int status[MAX];		// 優先順位
int count;			// 格納数

int main(void)
{
    int num;	// 入力される（格納される）値
    int index;	// 要素番号

    // ページ枠と優先順位の全ての要素に-1をセット
    init_page();

    printf("整数を入力してください(Ctrl+Zで終了)->");
    while(scanf("%d",&num) != EOF){			// Ctrl+Zで終了
        if(num < 0 || 999 < num){			// 入力範囲チェック
            printf("入力範囲に誤りがあります->");
            continue;
        }

    	// 入力値を検索して該当する要素番号を入れる
        index = ispage(num);

        if(index != NOTFOUND){			// 入力値ページ枠に存在する
            status_update(index);
        }
        else {					// 入力値ページ枠に存在しないが格納数に空きがある
            if(count < MAX){
                page_in(num);
            }
            else{				// 入力値ページ枠に存在しないかつ格納数に空きがない
                page_out(num);
            }
        }

        disp_page();
        printf("整数を入力して下さい(Ctrl+Zで終了)->");
        fflush(stdin);

    }
    return 0;
}

// ページ枠と優先順位の全ての要素に-1をセット
void init_page(void)
{
    int i;

    for(i = 0; i < MAX; i++){
        pages[i] = -1;
        status[i] = -1;
    }
}

// ページ枠から入力値を検索する
int ispage(int num)
{
    int i;

    for(i = 0; i < count; i++){
        if(pages[i] == num){
            return i;
        }
    }
    return NOTFOUND;
}

// ページ枠に要素入る
void page_in(int num)
{
    int i;

    // 優先順位を更新する
    for(i = 0; i < count; i++){
        status[i]++;
    }

    pages[i] = num;
    status[i] = 1;
    count++;
}

// ページング発生
void page_out(int num)
{
    int i;

    for(i = 0; i < count; i++){
        /*ページング場所の検索*/
        if(status[i] == MAX){
            printf("ページング発生：%d\n", pages[i]);
        pages[i] = num;
        status[i] = 1;
        }
        else{
            status[i]++;
        }
    }
}

// 優先順位の変更
void status_update(int index)
{
    int i;

    for(i = 0; i < count; i++){
        if(status[index] > status[i]){
            status[i]++;
        }
    }
    status[index] = 1;
}

// 優先順位とデータの表示
void disp_page(void)
{
    int i;

    printf("+----------+---+---+---+---+---+\n");

    /* 優先順位を表示する */
    printf("| 優先順位 ");
    for(i = 0; i < MAX; i++){
        if(status[i] == -1){
            printf("|   ");
        }
        else{
            printf("|%3d",status[i]);
        }
    }
    printf("|\n");
    printf("+----------+---+---+---+---+---+\n");

    /* 格納データを表示する */
    printf("| データ   ");
    for(i = 0; i < MAX; i++){
        if(pages[i] == -1){
            printf("|   ");
        }
        else{
            printf("|%3d",pages[i]);
        }
    }
    printf("|\n");
    printf("+----------+---+---+---+---+---+\n");
}

