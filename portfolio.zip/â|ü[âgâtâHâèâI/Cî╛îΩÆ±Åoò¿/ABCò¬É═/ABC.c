/* 
*プログラム名: 売り上げ分析（ABC分析）(ABC.c)
*作成者: 齋藤 桃音
*作成日: 2020/11/11
*概 要 : 売上分析(ABC分析)
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>

/* マクロ定義 */
#define MAX_RECORD 10				// 最大レコード数
enum rank { RANK_A = 80, RANK_B = 95};		// 評価

/* 構造体定義 */
typedef struct _sales {
    char name[20];		// 商品名
    int suryo;			// 数量
    int tanka;			// 単価
    int uriage;			// 売上高
    int total;			// 売上高累計
    double ratio;		// 構成比
    char rank;			// ランク
}SALES;

/* グローバル変数 */
int uriage_total;   //売上高合計(全部の合計)

/* 関数プロトタイプ宣言 */
int input_sales(SALES *uriage_data);			// 売上データの入力とセット
void sort_sales(SALES *uriage_data, int count);		// 売り上げデータのソート
void disp_report(SALES *uriage_data, int count);	// 分析レポートの表示
char get_rank(double ratio);				// 評価の計算

int main(void)
{
    SALES u[MAX_RECORD];		// 分析する商品情報配列
    int count;				// 入力件数
	
    // 商品名、数量、単価の入力、売上高、売上高合計の集計、入力件数のカウント
    count = input_sales(u);

    if(count > 0){
    	
    	// 売上高の降順に整列
        sort_sales(u,count);
    	
    	// 売上高累計、構成比の計算、get_rankに飛ぶ、売上データの表示
        disp_report(u,count);
    }

    // コンソールが閉じないようにする処理
    printf("\n終了するにはEnterキーを押してください ");
    while(1){
    	if('\r' == getch()) return 0;
    }

    return 0;

}

int input_sales(SALES *uriage_data)
{
    int count = 0;					// レコード件数
    int ret;						// scanfのエラー確認用変数

    while(count < MAX_RECORD){				// 件数が最大を超えないように
        printf("商品(終了:Ctrl + Z)＞");
        fflush(stdin);
        ret = scanf("%s",uriage_data -> name);

        if(ret == EOF){					// Ctrl + Zが入力されるまで
            break;
        }

        printf("数量＞");
        fflush(stdin);
        ret = scanf("%d",&uriage_data -> suryo);
        if(uriage_data -> suryo < 0 || ret != 1){	// エラーチェック
            puts("年間販売数は０以上を入力して下さい");
            continue;
        }

        printf("単価＞");
        fflush(stdin);
        ret = scanf("%d",&uriage_data -> tanka);
        if(uriage_data -> tanka < 0|| ret != 1){	// エラーチェック
            puts("単価は０以上を入力してください");
            continue;
        }

    	// 売上高を計算して売上高に格納
        uriage_data -> uriage = uriage_data -> tanka * uriage_data -> suryo;
    	
    	// 売上高を売上高合計（全商品）に集計　合計のところ用
        uriage_total += uriage_data -> uriage;
        count++;

        uriage_data++;					// 構造体配列を進める

    }
    return count;					// 実際に格納したレコード件数

}

void sort_sales(SALES *uriage_data, int count)
{
    int i,j;

    // 隣接交換法
    for(i = 0; i < count - 1; i++){
        for(j = i + 1; j < count; j++){
            if(uriage_data[i].uriage  < uriage_data[j].uriage){		// 降順にソート
                SALES w = uriage_data[i];
                uriage_data[i] = uriage_data[j] ;
                uriage_data[j] = w;
            }
        }
    }
}

void disp_report(SALES *uriage_data, int count)
{
    int i;
    static int sum = 0;

    puts("       ***  売 上 分 析 表  ***");
    puts("+------------------------------+------+------+--------+-----------+--------+-------+");
    puts("|          商 品 名            | 数量 | 単価 | 売上高 |売上高累計 | 構成比 |ランク |");
    puts("+------------------------------+------+------+--------+-----------+--------+-------+");

    for(i = 0; i < count; i++){
    	
    	// 今のところの累計
        sum += uriage_data -> uriage;
        uriage_data -> total = sum;
    	
    	// 構成比の計算
        uriage_data -> ratio = (double)uriage_data -> total * 100 / uriage_total;
    	
    	// ランク文字を求める（A,B,C）
        uriage_data -> rank = get_rank(uriage_data -> ratio);

        printf("|%-30s|%6d|%6d|%8d|%11d|%8.1f|%7c|\n",uriage_data -> name, uriage_data -> suryo, uriage_data -> tanka,
        uriage_data -> uriage, uriage_data -> total, uriage_data -> ratio, uriage_data -> rank);
        uriage_data++;
    }

    puts("+------------------------------+------+------+--------+-----------+--------+-------+");
    printf("|           合計               |             |%8d|\n",sum);
    puts("+------------------------------+------+------+--------+");
}

char get_rank(double ratio)
{
    // 評価を返す
    if(ratio <= 80){
        return('A');
    }
    else if(ratio <= 95){
        return('B');
    }
    else{
        return('C');
    }
}
