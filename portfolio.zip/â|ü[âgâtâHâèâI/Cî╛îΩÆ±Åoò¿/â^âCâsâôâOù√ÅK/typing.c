/* 
*プログラム名: C言語のタイピング練習プログラム（typing.c）
*作成者: 齋藤 桃音
*作成日: 2020/11/02
*概 要 : C言語のタイピング練習プログラム
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* マクロ定義 */
#define LENGTH 12		// 入力される文字列の長さ
#define MAX_KEYWORD 32		// 問題数
#define MAX_QUESTION 10		// 出題数
#define UNUSED 0		// 未出題
#define USED 1			// 出題済み

/* 関数プロトタイプ */
void init_status(int p[]);		// 出題テーブルの初期化
int create_question(int p[]);		// 問題を選定
int check(char *p1, char *p2);		// 正誤判定

int main(void)
{
	// 問題テーブル
    char *keyword[] = {"auto", "break", "case", "char", 
                        "const", "continue", "default", "do",
                        "double", "else", "enum", "extern",
                        "float", "for", "goto", "if",
                        "int", "long", "register", "return",
                        "short", "signed", "sizeof", "static",
                        "struct", "switch", "typedef", "union",
                        "unsigned", "void", "volatile", "while"
                    };
    
    char input[LENGTH];			// 入力文字列
    int status[MAX_KEYWORD];		// 出題管理テーブル
    int no;				// 問題番号
    int index;				// 出題番号
    int error_count = 0;		// 誤答回数

    /* 初期処理 */
    srand((unsigned)time(NULL));
    init_status(status);

    /* タイトル表示 */
    printf("***  C言語タイピング練習プログラム  ***\n");
    printf("画面に表示された文字列をキーボードから入力して下さい。\n\n");

    /* 主処理 */
    for(no = 1; no <= MAX_QUESTION; no++){		// 問題数分出し終わるまで繰り返し
        
    	index = create_question(status);		// 出題する文字列の番号を格納

        do{
            printf("[問%d] %s\n >>",no ,keyword[index]);
            gets(input);

            if(strlen(input) != strlen(keyword[index])){	// 入力文字数チェック
                puts("★入力文字数が間違っています。★");
                error_count++;
                continue;
            }

            if(check(input,keyword[index])){			// 間違ってる場所チェック
                puts("入力をやり直してください。");
                error_count++;
                continue;
            }

            break;
        }while(1);
    }

    printf("*** 再入力回数 = %d回\n", error_count);
    return 0;
}

void init_status(int *p)
{
    int i;
    for(i = 0; i < MAX_KEYWORD; i++,p++){
        *p = UNUSED;						// 出題管理テーブルに未出題をセット
    }
}

int create_question(int p[])
{
    int index;
    do{								// 出題済みでない問題が出るまで繰り返し
        index = rand() % MAX_KEYWORD;
    }while(p[index] == USED);				
	
    p[index] = USED;						// ループを抜けたら出題済みにする
    return index;						// 出題済みじゃない問題番号を返す
}

int check(char *p1, char *p2)
{
    int num = 1;

    while(*p1 != '\0'){						// 文字列の最後まで見る
        if(*p1 != *p2){						
            printf("★%d文字目の文字 [%c] は文字 [%c] です★\n", num,*p1,*p2);
            return num;						// 文字が一致してなかったら何番目の文字かを返す
        }

        num++;
        p1++;
        p2++;
    }

    return 0;
}