/* 
*プログラム名: HTMLタグ集計プログラム（HTML.c）
*作成者: 齋藤 桃音
*作成日: 2020/11/20
*概 要 : 指定したHTMLファイル内のHTMLタグの数を集計するプログラム
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* マクロ定義 */
#define MAX_RECORDS 120			// 最大レコード数
#define LENGTH 16			// タグ名の長さ
#define NOT_FOUND -1			// 該当なし
#define MSG_SIZE 80			// メッセージの長さ
#define TAG_FILE "taglist.txt"		// タグリストファイル名
#define OUT_FILE "tagsum.csv"		// 結果集計ファイル

/* タグ集計データ */
typedef struct {
    char tag_name[MAX_RECORDS];		// タグ名
    int count;				// 出現回数
}TAG;

/* 関数プロトタイプ宣言 */
void error_message(int ec, char *em);	
int init_tag(TAG *tag);
void html_count(char *f, TAG *tag);
int is_tag(char *ht, TAG *tag);
void sort_tag(int count, TAG *tag);
void file_out(int count, TAG *tag);

int main(int argc, char *argv[])
{
    TAG tag[MAX_RECORDS];	// タグ集計配列
    int record_count;		//ファイル入力件数

    if(argc != 2){		//エラー001判定
        error_message(1,"使用方法：kadai112 [HTML ファイル名]");
        exit(1);
    }
    record_count = init_tag(tag);	// レコード件数を格納、初期化
    html_count(argv[1], tag);		

    sort_tag(record_count, tag);
    file_out(record_count, tag);
    return 0;
}

void error_message(int ec, char *em)
{
    printf("ERROR%03d:%s\n",ec,em);	// エラーメッセージ表示
}

int init_tag(TAG *tag)
{
    FILE *fp;
    int count = 0;

    if((fp = fopen("taglist.txt","r")) == NULL)		// エラー002
    {
        char msg[MSG_SIZE];
        strcpy(msg, "タグファイル(");
        strcat(msg, TAG_FILE);
        strcat(msg, ")が開けません");
        error_message(2,msg);
        exit(2);
    }

    while(fscanf(fp,"%s",tag[count].tag_name) != EOF){
        tag[count].count = 0;
        if(count >= MAX_RECORDS - 1){			// エラー006
            error_message(6,"タグ一覧ファイルが最大レコード件数を超えています。");
            exit(6);
        }
        count++;
    }
    fclose(fp);
    return count;			// レコード件数を返す
}

void html_count(char *filename, TAG *tag)
{
    FILE *fp;
    char tag_name[LENGTH];
    int c;
    int len;
    int index;

    if((fp = fopen(filename,"r")) == NULL){	//エラー003
        char msg[MSG_SIZE];
        strcpy(msg, "引数に指定されたファイル(");
        strcat(msg, filename);
        strcat(msg, ")が開けません");
        error_message(3,msg);
        exit(3);
    }

    while((c = fgetc(fp))  != EOF){
        if(c == '<'){			// cが<
            c = fgetc(fp);		

            if(isalpha(c)){		// 次の文字がアルファベット
                for(len = 0; len < LENGTH - 1; len++){
                    if(c == '>' || c == ' ' || c == EOF){
                        break;
                    }
                    tag_name[len] = tolower(c);
                    c = fgetc(fp);
                }
                tag_name[len]= '\0';   

                index = is_tag(tag_name,tag);

                if(index != NOT_FOUND){
                    tag[index].count++;
                }
                else{			// エラー005
                    char msg[MSG_SIZE];
                    strcpy(msg, "タグ名が不明です。");
                    strcat(msg, tag_name);
                    error_message(5,msg);
                } 
            }    
        }
    }
    fclose(fp);    //ファイルを閉じる
}

int is_tag(char *str, TAG *tag)
{
    int i;

    for(i = 0; i < MAX_RECORDS; i++){
        if(strcmp(str, tag[i].tag_name) == 0){
            return i;					// 見つかったら何番目のタグかを返す
        }
    }
    return NOT_FOUND;
}

void sort_tag(int count, TAG *tag)
{
    int i,j;

    for(i = 0; i < count - 1; i++){
        for(j = i + 1; j < count; j++){
            if(tag[i].count < tag[j].count){		// 降順にソート
                TAG w = tag[i];
                tag[i] = tag[j];
                tag[j] = w;
            }
        }
    }
}

void file_out(int count, TAG *tag)
{
    FILE *fp;
    int i;

    if((fp = fopen(OUT_FILE,"w")) == NULL){	// エラー004
        char msg[MSG_SIZE];
        strcpy(msg, "集計ファイル(");
        strcat(msg, OUT_FILE);
        strcat(msg, ")が開けません");
        error_message(4,msg);
        exit(4);
    }

    printf("\n*** HTML タグ利用回数 ***\n");
    printf("+----------------+------+\n");
    printf("|                | 回数 |\n");
    printf("+----------------+------+\n");

    for(i = 0; i < count; i++){
        if(tag[i].count > 0){			// 見つかったタグだけ表示
            fprintf(fp,"%16s,%6d\n",tag[i].tag_name,tag[i].count);
            printf("|%-16s|%6d|\n",tag[i].tag_name,tag[i].count);
        } 
    }
    printf("+----------------+------+\n");

    fclose(fp);
}
